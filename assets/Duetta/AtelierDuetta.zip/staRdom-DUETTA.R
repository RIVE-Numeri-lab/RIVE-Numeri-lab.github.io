# PARAFAC tutorial based off of Matthias Pucher'  staRdom tutorial version 2023-06-15
# https://cran.r-project.org/web/packages/staRdom/vignettes/PARAFAC_analysis_of_EEM.html#import-raw-data
# It has been simplified for Duetta users at UQTR and associate GRIL members
# note : when i make reference to Mathlab, i mean the free drEEM toolbox by Murphy et al., 2013
# https://pubs.rsc.org/en/content/articlelanding/2013/ay/c3ay41160e


# LIBRARIES ####
install.packages("staRdom")   # current version 1.1.28

library(dplyr)
library(tidyr)
library(staRdom)   # Github version is more recent according to Pucher
library(ggplot2)

# library(eemR)

# set number of CPU cores to speed up computer's efficiency
cores <- detectCores(logical=FALSE) 
cores # I have 12 cores



# DATA PREP AND CORRECTIONS  ####
# make sure you set your working directory and that fluo folder containing EEMs is in this directory 

#### 4.0 : Import raw EEMs ####
EEM <- eem_read("fluo", import_function = "aqualog")  

# Plot raw EEMs, 9/page
eem_overview_plot(EEM, spp=9, contour = TRUE)   # Mathlab offers to visualize EEMs in 3D with interactive viewing function

# Re-scale (cut) wavelength bands by taking out ex >500
EEM <- eem_range(EEM, ex = c(250,500), em = c(0,600))



# skipping following sections since the Duetta corrects for all of these.
# a short description in included so that you may appreciate all the work saved with this new instrument.
# 5.1 : Changing samples names
# 5.2 : Absorbance baseline correction
# 5.3 : Spectral Instrument specific) correction
# 5.4 : Blank subtraction
# 5.5 : Inner filter effect (IFE) correction
# 5.6 : Raman normalization (area under curve) - Duetta beta software still being tested for this
# 5.7 : Removing blanks from sample list


#### 5.8 : Scattering - remove and interpolate ####
# RAM1, RAM2, RAY1, RAY2
remove_scatter <- c(FALSE, FALSE, TRUE, FALSE)  # you only need to correct for Rayleigh 1st order with Duetta
# Below, you will need to visually explore results to find the optimal value for your dataset (using ln 62).
# ideally, you want to remove as little as possible as to not lose too much information but enough that you don't keep noise that might end up modeled.
# Mathlab offers better visualization tools to see if you have cut out too much or too little.
remove_scatter_width <- c(0,0,20,0)             # Mathlab offers more control : above and below values
 
EEMlist <- eem_rem_scat(EEM, remove_scatter = remove_scatter, remove_scatter_width = remove_scatter_width)
# Alternatively, you can use the following code that does everything at once :
# eem_list <- eem_rem_scat(eem_list, remove_scatter = c(FALSE, FALSE, TRUE, FALSE), remove_scatter_width = c(0,0,20,0), interpolation = FALSE, cores = cores)

# Plot corrected EEMs / removed scatter will be greyed out
eem_overview_plot(EEMlist, spp=9, contour = TRUE)

# INTERPOLATION of cut out scatter : different interpolation types are available (filling in the blanks)
# type 0: setting all NAs to 0
# type 1: spline interpolation with mba.points (what Pucher uses in his tutorial)
# type 2: excitation and emission wl-wise interpolation with pchip
# type 3: excitation wl-wise interpolation with pchip
# type 4: linear excitation and emission wl-wise interpolation with na.approx and against subsequent mean calculation.  (what Mathlab uses)

# extend = FALSE :  prevents function from extrapolating // accurate in interpolating surfaces according to staRdom creator

# drEEM toolbox in Mathlab uses linear interpolation by default (type 4)
# staRdom uses type = 1 in tutorial
EEMlist <- eem_interp(EEMlist, cores = cores, type = 4, extend = FALSE)    # interpolation not as good as Mathlab. interpolates extra data in cut out scatter region
# view EEMs
eem_overview_plot(EEMlist, spp=9, contour = TRUE)                          



# 5.9 : skipping dilution correction - as long as absorbance is below 1.5, you do not need to dilute
# 5.10 : skipping smoothing - not recommended for PARAFAC

# 5.11  shows you what corrections were made to your eems
summary(EEMlist)

# 6-7 : skipped


# CREATING A MODEL ####
# if working with EEMs from different machines, you will need to standardize datasets among themselves, see staRdom tutorial for details

#### 8.3 : Removing noisy EEMS #### 
# based off visual observations (ln 101). Again, Mathlab offers better visual information to achieve this step.
# eem_extract        remove whole EEM by name or number
# eem_range          removes data outside given wavelength in all samples
# eem_exclude        removes data from sample set, from a list
# eem_rem_scat        set scatter data to NA removes several scatters in one step
# eem_remove_scatter  set scatter data to NA removes one scatter type at a time
# eem_setNA           replaces data by NA in rectangular shape ie. clay
eem_overview_plot(EEMlist, spp=9, contour = TRUE)    


#### 8.4 : Preliminary model ####
# prepping model parameters
dim_min <- 2   # nombre de composantes minimum
dim_max <- 7   # nombre de composantes Max (selon F.G., maximum qu'il a vu c'est 8 de son propre doc mais il s'amusait à analyser des leachates frais en labo, dans la vrai vie on se rendra pas à ça)
# nstart and maxit values can be played around with. You might need to if you get an error message. 
# ex warining message :  "The PARAFAC model with 5 components did not converge! Increasing the number of initialisations (nstart) or iterations (maxit) might solve the problem."
nstart <- 25    
maxit = 2000   
ctol <- 10^-6


# calculating PARAFAC model, unconstrained
# unconstrained: no restrictions applied to values of EEM. model is free to use +ve or -ve values. produces mathematical good fits (lower residual) 
#                  but is sort of meaningless bc fluo values cant be -ve. Difficult to interpret components.
# pf1 <- eem_parafac(EEMlist, comps = seq(dim_min,dim_max), 
#                   normalise = FALSE, 
#                   const = c("uncons", "uncons", "uncons"), 
#                   maxit = maxit, 
#                   nstart = nstart, 
#                   ctol = ctol, 
#                   cores = cores)

# calculating PARAFAC model using non-negative constraints (as per Murphy, 2013)
# non-negative:   all elements of EEM are = or > than 0. Results are easier to interpret and chemically realistic.
#                 Components resemble actual fluo spectra of fluorophores. Fit can be slightly worst b/c model has fewer Degrees of freedom.  
pf1n <- eem_parafac(EEMlist, comps = seq(dim_min,dim_max), 
                    normalise = FALSE, 
                    const = c("nonneg", "nonneg", "nonneg"), 
                    maxit = maxit, 
                    nstart = nstart, 
                    ctol = ctol, 
                    cores = cores)


# other constraints exist: have a look at CMLS::const()

# ONLY USING NON-NEG MODEL FROM NOW ON, see Murphy 2013

# RESCALING models to a maximum fluorescence of 1 for each component.
# "In case of uneven peak heights, eempf_rescaleBC can help to improve the visibility of your graphs."
# will only be using non-constrained model from now on as per Murphy, 2013              
pf1n <- lapply(pf1n, eempf_rescaleBC, newscale = "Fmax")


# COMPARE MODEL COMPONENTS - 3 GRAPHS helps determine how many components we should keeps
eempf_compare(pf1n, contour = TRUE)   # notice that the results aren't pretty. We fix this below...



#### 8.5 : Correlation ####
# shows correlation  between models of different number of components 
# "The PARAFAC algorithm assumes no correlation between the components. If samples are in a wide range of DOC concentrations, 
# a correlation of the components is likely. To avoid that, the samples can be normalized." 
eempf_cortable(pf1n[[5]], normalisation = FALSE)                  # shows correlation table
eempf_corplot(pf1n[[5]], progress = FALSE, normalisation = FALSE) # shows correlation graphs
# "As some of the components are highly correlated, the model is calculated again with normalized sample data. Later normalization is reversed automatically [...]"



#### 8.5 : Normalization ~ DOC ####
# "The PARAFAC algorithm assumes no correlation between the components. If samples are in a wide range of DOC concentrations, a correlation of the components is likely."
# also, my model sucks! lets normalize data (bc i have a wide range of DOC values) 
pf2n <- eem_parafac(EEMlist, comps = seq(dim_min,dim_max), 
                   normalise = TRUE, 
                   const = c("nonneg", "nonneg", "nonneg"), 
                   maxit = maxit, 
                   nstart = nstart, 
                   ctol = ctol, 
                   cores = cores)

# rescale B and C modes - improves visibility of graphs
pf2n <- lapply(pf2n, eempf_rescaleBC, newscale = "Fmax")

# shows model results ( 3 graphs)
eempf_compare(pf2n, contour = TRUE)     # RESULTS ARE MUCH BETTER!!! 
 

# This code lets you plot only the components graph (quicker execution)
# eempf_plot_comps(pf2n, contour = TRUE, type = 1)     


# DECIDE HOW MANY COMPONENTS YOU ARE KEEPING - ie. [[4]] 
# eempf_corplot(pf2n[[4]], progress = FALSE, normalisation = FALSE)   # this line codes for correlation



# PERFECTING THE MODEL ####

#### 8.6 : Excluding outliers  ####
# leverage : find specific samples that have a higher leverage (outliers) on -component results than should be normal
cpl <- eempf_leverage(pf2n[[4]])
eempf_leverage_plot(cpl,qlabel=0.1)   # plot leverage samples

# Excluding leveraging samples AUTOMATICALY - not used today
# exclude <- eempf_leverage_indent(cpl,qlabel=0.1)

# Excluding leveraging samples MANUALLY - recommended to keep track of changes
exclude <- list(
  "ex" = c(),
  "em" = c(),
  "sample" = c("sample1-1", "sample2-2")
)

# exclude samples from data set
eem_list_ex <- eem_exclude(EEMlist, exclude)

# generate new model without outliers
pf3n <- eem_parafac(eem_list_ex, comps = seq(dim_min,dim_max), 
                          normalise = TRUE, 
                          const = c("nonneg", "nonneg", "nonneg"), 
                          maxit = maxit, 
                          nstart = nstart, 
                          ctol = ctol, 
                          cores = cores)

# Example WARNING MSG you might get at this point : 
#  In FUN(X[[i]], ...) :
#  Calculating the 7 components model, 12 out of 25 models converged! You might want to increase the number of initialisations (nstart) or iterations (maxit).



# improving graph visuals
pf3n <- lapply(pf3n, eempf_rescaleBC, newscale = "Fmax")
# plot resulting model components
eempf_plot_comps(pf3n, contour = TRUE, type = 1)
# find leverages again
eempf_leverage_plot(eempf_leverage(pf3n[[4]]),qlabel=0.1)


# RERUN SECTION 8.6 AS MANY TIMES AS IT TAKES.
# It's a balancing act between getting rid of leveraging samples (outliers) but not too many that the model is over-fitted. 
# I stop when leverages left are around 0.1. Aim not to take out more than 10 % of total samples.





#### 8.7 : Residuals ####
# "Analyzing these residuals can show deficits in model creation, 
# problems with sample handling and lab equipment or it can already be helpful in answering scientific questions."
eempf_residuals_plot(pf3n[[4]], EEMlist, residuals_only = TRUE,  spp = 9, cores = cores, contour = TRUE)





#### 8.8 : Recalculating model - with more accuracy  ####
# here we increase model parameters - it will take longer to compute
ctol <- 10^-8 # decrease tolerance in PARAFAC analysis
nstart = 20 # number of random starts
maxit = 10000 # increase number of maximum iterations

pf4 <- eem_parafac(eem_list_ex, 
                   comps = 4,                   # don't forget to change number of components here
                   normalise = TRUE, 
                   const = c("nonneg", "nonneg", "nonneg"), 
                   maxit = maxit, 
                   nstart = nstart, 
                   ctol = ctol, 
                   output = "all", 
                   cores = cores, 
                   strictly_converging = TRUE)


pf4 <- lapply(pf4, eempf_rescaleBC, newscale = "Fmax")

# check convergence behaviour created by model
eempf_convergence(pf4[[1]])
# all should converge






#### 8.9 : Plotting components and loadings ####
# "The components’ shapes are important for an interpretation from a chemical point of view."
# "The loadings show the fluorescence differences of different components in different samples."
# Graph 1: component shape // Graph 2 : loadings
eempf_comp_load_plot(pf4[[1]], contour = TRUE)




#### 8.11 : SPLIT HALF ANALYSIS ####
# Model validation : THIS TAKES A LOOOONG TIME!
# The split-half analysis is intended to show the stability of your model. The data is recombined in 6 different ways and results from each sub-sample should be similar (Murphy et al. 2013).
# don't forget to change the number of components (after eem_list_ex in this example) 
sh <- splithalf(eem_list_ex, 4, normalise = TRUE, rand = FALSE, cores = cores, nstart = nstart, strictly_converging = TRUE, maxit = maxit, ctol = ctol)

# This is the moment of truth where you plot the results of the split-half analysis. 
# Visually validate the model (lines should be one on top of each other).
splithalf_plot(sh) 

# The following code shows the similarity of each combination of splits. Values should be close to 1. 
tcc_sh_table <- splithalf_tcc(sh)
tcc_sh_table


# 8.12 : skipping Loading of outliers


# FURTHER MODEL VALIDATION ####

# 8.13.1 : skipping core consistency
# Please see Murphy et al. (2013) for the limited usability of core consistency for model validation from natural EEMs.

# 8.13.2 : skipping EEMqual
# "EEMqual is a quality parameter integrating the model fit, the core consistency and the split-half analysis according to Bro and Vidal (2011). Due to the fact that the core consistency is included, the limitations are similar (see above)."
# eemqual <- eempf_eemqual(pf4[[1]], eem_list_ex, sh, cores = cores)

# 8.13.3 : skipping verification of importance of components 
# varimp <- eempf_varimp(pf4[[1]], eem_list_ex, cores = cores)



# FORMATING MODEL ####

# 9 : Making component graph pretty 
# set new model names, number of models must be equal to number of names
eempf_comp_names(pf4) <- c("C1","C2","C3","C4")

# plot new component graph with new names
pf4[[1]] %>%
  ggeem(contour = TRUE)





# EXPORT MODEL ####

# 10.1 : Open Fluor 
eempf_openfluor(pf4[[1]], file = "1.OpenFluor_Model.txt")
# manually input information in headers before loading model to open fluor for others to compare to
# Please note, i have yet to find how to extract component peaks which are very useful when comparing components to other models (i found mistakes in open fluor that way....)


# 10.3 : create report (HTML)
eempf_report(pf4[[1]], export = "2.Parafac_Report.html", eem_list = eem_list_ex, shmodel = sh, performance = TRUE)


# 10.4 : Export model (r.u.)
model<- eempf_export(pf4[[1]], export = NULL, Fmax = TRUE)
model
# you can obtain component percentages through excel function: (sum all component values - this is your 100%, then with rule of 3, calculate % for each component for each sample)

# component values for each sample included in model
write.csv(model, "3.Results.csv")
# why are there 3 comp outputs? one normal comp, one for ex and one for em components???

# a thanks to Jade for the following code
# Typically, you now use the model and run all of your samples through it. 
totalresults <- A_missing(EEMlist, pf4[[1]], cores = cores)
write.csv(totalresults, "3.TotalResults.csv")

# you also want to extract the coordinates (ex, em) for each of you component peaks
em <- data.frame(pf4[[1]][["B"]])  # "B" is for Emission
ex <- data.frame(pf4[[1]][["C"]])  # "C" is for Excitation

#max(em$C1)     # maximums will always be 1.0000 ^ 00, look for this values and manually extract it
# the function also cannot identify secondary peak coordinates, you need to do this manually

# Component coordinates (ex "C", em "B")
# important to validate when comparng to Open Fluor database (i have avoided interpretation mistakes cross validating this way)
# C1   252 , 422
# C2   264 , 489
# C3   304 , 297
# C4   348 , 369


# Comparing both Mathlab and staRdom, I much prefer Mathlab.
# The drEEM toolbox in Mathlab is free (license is free with the university).
# It is well worth the time and effort of learning a new software and new programming language for all the added control you get over tweaking, creating and extracting your model.








